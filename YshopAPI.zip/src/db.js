var db = {
    host: 'yshop.cfsxlfyyqzgp.ap-northeast-2.rds.amazonaws.com',
    user : 'admin',               
    password : 'ghksrhfxkfxo55555',
    database : 'Y#',
    multipleStatements: true
};
module.exports=db;